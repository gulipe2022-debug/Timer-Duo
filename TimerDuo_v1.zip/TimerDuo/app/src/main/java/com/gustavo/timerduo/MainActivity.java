package com.gustavo.timerduo;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    static final int PORT = 45454;
    LinearLayout root;
    TextView timer, status, ipText;
    Handler handler = new Handler(Looper.getMainLooper());
    volatile long startNs = 0L;
    volatile long frozenNs = 0L;
    volatile boolean running = false;
    ServerSocket serverSocket;
    Socket socket;
    BufferedReader in;
    PrintWriter out;
    final AtomicBoolean connected = new AtomicBoolean(false);

    int green = Color.rgb(57,255,20);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView tv(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER); t.setPadding(20,20,20,20);
        return t;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(18); b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        return b;
    }

    void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28,28,28,28);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
    }

    void showHome() {
        base();
        TextView title = tv("TIMER DUO", 34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(green);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = tv("2 celulares • 1 cronômetro", 18);
        root.addView(sub);

        Button panel = btn("📺  USAR COMO PAINEL");
        Button controller = btn("🔘  USAR COMO BOTÃO");
        root.addView(panel, lp());
        root.addView(controller, lp());

        panel.setOnClickListener(v -> showPanel());
        controller.setOnClickListener(v -> showController());
    }

    LinearLayout.LayoutParams lp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 70);
        p.setMargins(0,16,0,16);
        return p;
    }

    void showPanel() {
        base();
        TextView h = tv("PAINEL", 28);
        h.setTextColor(green); h.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(h);

        timer = tv("00:00.00", 58);
        timer.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timer.setTextColor(green);
        root.addView(timer, new LinearLayout.LayoutParams(-1, 180));

        status = tv("Iniciando conexão...", 18);
        root.addView(status);

        ipText = tv("IP: procurando...", 16);
        root.addView(ipText);

        Button reset = btn("↺ ZERAR");
        Button back = btn("Voltar");
        root.addView(reset, lp());
        root.addView(back, lp());

        reset.setOnClickListener(v -> {
            running = false; frozenNs = 0; startNs = 0;
            updateTimer();
            send("RESET");
        });
        back.setOnClickListener(v -> { stopNetwork(); showHome(); });

        new Thread(this::startServer).start();
        handler.post(updateRunnable);
    }

    void startServer() {
        try {
            serverSocket = new ServerSocket(PORT);
            String ip = localIp();
            runOnUiThread(() -> {
                ipText.setText("IP do painel: " + ip + "\nNo outro celular, digite este IP.");
                status.setText("Aguardando o celular do botão…");
            });
            socket = serverSocket.accept();
            connected.set(true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            runOnUiThread(() -> status.setText("● BOTÃO CONECTADO"));
            String line;
            while ((line = in.readLine()) != null) handleCommand(line);
        } catch (Exception e) {
            runOnUiThread(() -> { if (status != null) status.setText("Conexão encerrada"); });
        }
    }

    void handleCommand(String cmd) {
        if ("START".equals(cmd)) {
            if (!running) {
                startNs = System.nanoTime() - frozenNs;
                running = true;
            }
        } else if ("STOP".equals(cmd)) {
            if (running) {
                frozenNs = System.nanoTime() - startNs;
                running = false;
            }
        } else if ("RESET".equals(cmd)) {
            running = false; frozenNs = 0; startNs = 0;
        }
        runOnUiThread(this::updateTimer);
    }

    Runnable updateRunnable = new Runnable() {
        public void run() {
            updateTimer();
            handler.postDelayed(this, 10);
        }
    };

    void updateTimer() {
        if (timer == null) return;
        long ns = running ? System.nanoTime() - startNs : frozenNs;
        long ms = Math.max(0, ns / 1_000_000L);
        long minutes = ms / 60000;
        long seconds = (ms / 1000) % 60;
        long centis = (ms / 10) % 100;
        timer.setText(String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, centis));
    }

    void showController() {
        base();
        TextView h = tv("BOTÃO", 30);
        h.setTextColor(green); h.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(h);

        EditText ip = new EditText(this);
        ip.setHint("IP do painel (ex.: 192.168.1.10)");
        ip.setHintTextColor(Color.GRAY); ip.setTextColor(Color.WHITE);
        ip.setSingleLine(true);
        root.addView(ip, new LinearLayout.LayoutParams(-1,70));

        Button connect = btn("🔗 CONECTAR");
        root.addView(connect, lp());

        status = tv("1. Coloque os dois celulares na mesma rede Wi‑Fi ou hotspot.\n2. No painel, veja o IP.\n3. Digite o IP aqui.", 17);
        root.addView(status);

        Button big = btn("▶  START");
        big.setTextSize(30);
        big.setTextColor(Color.BLACK);
        big.setBackgroundColor(green);
        big.setEnabled(false);
        root.addView(big, new LinearLayout.LayoutParams(-1,180));

        Button reset = btn("↺ ZERAR");
        root.addView(reset, lp());

        Button back = btn("Voltar");
        root.addView(back, lp());

        connect.setOnClickListener(v -> new Thread(() -> connectToPanel(ip.getText().toString().trim(), big)).start());
        big.setOnClickListener(v -> {
            if (out == null) return;
            boolean start = big.getText().toString().contains("START");
            send(start ? "START" : "STOP");
            runOnUiThread(() -> {
                big.setText(start ? "■  STOP" : "▶  START");
                big.setTextColor(start ? Color.WHITE : Color.BLACK);
            });
        });
        reset.setOnClickListener(v -> { send("RESET"); runOnUiThread(() -> { big.setText("▶  START"); big.setTextColor(Color.BLACK); }); });
        back.setOnClickListener(v -> { stopNetwork(); showHome(); });
    }

    void connectToPanel(String host, Button big) {
        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(host, PORT), 5000);
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            connected.set(true);
            runOnUiThread(() -> {
                status.setText("● CONECTADO AO PAINEL");
                big.setEnabled(true);
            });
        } catch (Exception e) {
            runOnUiThread(() -> status.setText("Não conectou. Confira o IP e a mesma rede Wi‑Fi."));
        }
    }

    void send(String s) {
        if (out != null) out.println(s);
    }

    String localIp() {
        try {
            for (java.util.Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface ni = en.nextElement();
                for (java.util.Enumeration<InetAddress> en2 = ni.getInetAddresses(); en2.hasMoreElements();) {
                    InetAddress a = en2.nextElement();
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) return a.getHostAddress();
                }
            }
        } catch(Exception ignored) {}
        return "IP não encontrado";
    }

    void stopNetwork() {
        try { if (socket != null) socket.close(); } catch(Exception ignored) {}
        try { if (serverSocket != null) serverSocket.close(); } catch(Exception ignored) {}
        connected.set(false);
        handler.removeCallbacks(updateRunnable);
    }
}
