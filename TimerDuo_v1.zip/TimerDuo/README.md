# Timer Duo — primeira versão

App Android para a brincadeira do cronômetro com dois celulares:

- Celular 1: **PAINEL**, mostra `00:00.00` em números grandes.
- Celular 2: **BOTÃO**, envia START/STOP/RESET para o painel.
- Os dois aparelhos usam a mesma rede Wi‑Fi ou o hotspot de um deles.
- O painel é quem mantém o tempo, então o relógio não depende do segundo celular.

## Como usar
1. Instale o mesmo APK nos dois celulares.
2. No primeiro, escolha **USAR COMO PAINEL**.
3. Veja o IP mostrado pelo painel.
4. No segundo, escolha **USAR COMO BOTÃO** e digite o IP.
5. Toque em CONECTAR.
6. START começa; STOP para; ZERAR reinicia.

## Observação
Esta é a primeira versão/protótipo. Ela não precisa de servidor externo nem de conta.
Para gerar um APK no Android Studio, abra esta pasta como projeto Gradle e use:
Build > Build APK(s).

Projeto criado sem bibliotecas externas.
